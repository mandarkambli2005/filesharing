from django.contrib import admin
from .models import User, File_Upload

# Register your models here.
admin.site.register(User)
admin.site.register(File_Upload)